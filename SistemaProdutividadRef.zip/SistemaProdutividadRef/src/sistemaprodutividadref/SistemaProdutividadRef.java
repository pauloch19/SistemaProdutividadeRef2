package sistemaprodutividadref;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class SistemaProdutividadRef {

    /**
     * @param args the command line arguments
     */
    Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        Sys system = new Sys();
        Presentation pres = new Presentation();
        System.out.println("Bem vindo ao sistema de produtividade acadêmica.");
        pres.Presentation(system);
    }
    
    
    
}
