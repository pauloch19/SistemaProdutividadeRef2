/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;

/**
 *
 * @author paulc
 */
public class Publications extends AcademicsProductions{
    Project associatedProject = null;
    java.util.ArrayList<Person> authors = new java.util.ArrayList<>();
    
    public Publications(String title, String conferenceName, int year){
        super(title, conferenceName, year);   
    }
    
    public boolean VerifyParticipants(String email){
        boolean found = false;
        int i;
        Person person;
        for(i=0;i<authors.size();i++)
        {
            person = authors.get(i);
            if(person.getEmail().equals(email))
            {
                found = true;
                break;
            }
        }
        return found;
    }
    
}
