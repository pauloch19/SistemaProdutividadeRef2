/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;

/**
 *
 * @author paulc
 */
public class Orientations extends AcademicsProductions{
    java.util.ArrayList<Person> teachers = new java.util.ArrayList<>();
    java.util.ArrayList<Person> students = new java.util.ArrayList<>();
    public Orientations(String title, String conferenceName, int year){
        super(title, conferenceName, year);   
    }
    
    public boolean VerifyParticipationTeacher(String email)
    {
        boolean found = false;
        int i;
        Person person;
        for(i=0;i<teachers.size();i++)
        {
            person = teachers.get(i);
            if(person.getEmail().equals(email))
            {
                found = true;
                break;
            }
        }
        return found;
    }
    
    public boolean VerifyParticipationStudent(String email)
    {
        boolean found = false;
        int i;
        Person person;
        for(i=0;i<students.size();i++)
        {
            person = students.get(i);
            if(person.getEmail().equals(email))
            {
                found = true;
                break;
            }
        }
        return found;
    }
            
}
