/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


/**
 *
 * @author paulc
 */
public class Sys {
    java.util.ArrayList<Project> elaboration= new java.util.ArrayList<>();
    java.util.ArrayList<Project> inProgress= new java.util.ArrayList<>();
    java.util.ArrayList<Project> finished = new java.util.ArrayList<>();
    Map<String, Person> contributors = new HashMap<String, Person>();
    java.util.ArrayList<Publications> publications = new java.util.ArrayList<>();
    java.util.ArrayList<Orientations> orientations = new java.util.ArrayList<>();
    public boolean VerifyTitle(String title)
    {
        int i;
        Project pj;
        boolean v = false;
        for(i=0;i<elaboration.size();i++)
        {
            pj = elaboration.get(i);
            if(pj.getTitle().equals(title))
            {
                v = true;
                break;
            }
        }
        return v;
    }
    
    public Project SearchProject(String title)
    {
        int i;
        Project pj;
        Project found = null;
        for(i=0;i<elaboration.size();i++)
        {
            pj = elaboration.get(i);
            if(pj.getTitle().equals(title))
            {
                found = pj;
                break;
            }
        }
        return found;
    }
    
    
    public Project SearchProjectInProgress(String title)
    {
        int i;
        Project pj;
        Project found = null;
        for(i=0;i<inProgress.size();i++)
        {
            pj = inProgress.get(i);
            if(pj.getTitle().equals(title))
            {
                found = pj;
                break;
            }
        }
        return found;
    }
    
    public Publications VerifyPublication(String title)
    {
        int i;
        Publications publi = null;
        for(i=0;i<publications.size();i++)
        {
            publi = publications.get(i);
            if(publi.getTitle().equals(title))
            {
                break;
            }
        }
        return publi;
        
    }
    
     public Orientations VerifyOrientation(String title)
    {
        int i;
        Orientations ori = null;
        for(i=0;i<orientations.size();i++)
        {
            ori = orientations.get(i);
            if(ori.getTitle().equals(title))
            {
                break;
            }
        }
        return ori;
        
    }
}
