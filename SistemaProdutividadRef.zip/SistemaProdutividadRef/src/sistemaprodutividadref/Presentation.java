/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;
import java.util.Scanner;
/**
 *
 * @author paulc
 */
public class Presentation {
    
    Scanner input = new Scanner(System.in);
    public void Presentation(Sys system){
        int option;
        System.out.println("1.Adicionar colaborador ao sistema\n2.Criar Projeto\n3.Alocar Participante a projeto");
        System.out.println("4.Mudar fase de elaboração para em progresso\n5.Mudar fase de em progresso para concluido\n6.Produções Acadêmicas");
        System.out.println("7.Fazer Consulta no sistema\n8.Gerar relatório");
        option = Treatment("Escolha uma das opções acima: ");
        input.nextLine();
        while(option!=10)
        {
            if(option==1)
            {
                System.out.println("Você entrou na opção de adicionar um colaborador ao sistema");
                AddContributor(system);
            }
            if(option==2)
            {
                System.out.println("Você entrou na opção criar projeto.");
                CreateProject(system);
            }
            if(option==3)
            {
                System.out.println("Você entrou na opção alocar participante a um projeto.");
                ParticipantAllocation(system);
            }
            if(option==4)
            {
                System.out.println("Você entrou na opção mudar fase de um projeto em elaboração para em progresso..");
                ElaborationToProgress(system);
            }
            if(option==5)
            {
                System.out.println("Você entrou na opção mudar fase de um projeto em progresso para concluido");
                ProgressToFinished(system);
            }
            if(option==6)
            {
                System.out.println("Você entrou na opção produções acadêmicas.");
                System.out.println("1.Criar publicação\n2.Criar orientação\n3.Adicionar autor a publicação\n4.Adicionar projeto a uma publicação");
                System.out.println("5.Adicionar publicação a um projeto.\n6.Adicionar um professor a uma orientação\n7.Adicionar colaboradores a uma orientação");
                option = Treatment("Escolha uma das opções acima: ");
                if(option==1)
                {
                    CreatePublication(system);
                }
                if(option==2)
                {
                    CreateOrientation(system);
                }
                if(option==3)
                {
                    AddAuthorsToPublication(system);
                }
                if(option==4)
                {
                    AddProjectToPublication(system);
                }
                if(option==5)
                {
                    AddPublicationToProject(system);
                }
                if(option==6)
                {
                    AddTeachersToOrientation(system);
                }
                if(option==7)
                {
                    AddStudentToOrientation(system);
                }
            }
            else if(option==7)
            {
                System.out.println("Você entrou na opção fazer consulta no sistema");
                System.out.println("1.Consulta por colaborador\n2.Consulta por projeto");
                option = Treatment("Escolha uma das opções acima: ");
                if(option==1)
                {
                    
                }
                if(option==2)
                {
                    
                }
            }
            else if(option==8)
            {
                System.out.println("Você entrou na opção gerar relatório.");
            }
            System.out.println("1.Adicionar colaborador ao sistema\n2.Criar Projeto\n3.Alocar Participante a projeto");
            System.out.println("4.Mudar fase de elaboração para em progresso\n5.Mudar fase de em progresso para concluido\n6.Produções Acadêmicas");
            option = Treatment("Escolha uma das opções acima: ");
            input.nextLine();
        }
        
    }
    
    public void AddContributor(Sys system)
    {
        System.out.print("Nome: ");
        String name = input.nextLine();
        System.out.print("Email: ");
        String email = input.nextLine();
        Person contributor = null;
        while(system.contributors.containsKey(email))
        {
            System.out.println("Já existe um usuário com esse email, digite outro por favor.");
            System.out.print("Email: ");
            email = input.nextLine();
        }
        System.out.println("Qual o tipo do colaborador: ");
        String type = input.nextLine();
        if(type.equals("graduacao"))
        {
            contributor = new GraduateStudent(name, email);
        }
        if(type.equals("mestrado"))
        {
            contributor = new MasteringStudent(name, email);
        }
        if(type.equals("doutorado"))
        {
            contributor = new PhdStudent(name, email);
        }
        if(type.equals("professor"))
        {
            contributor = new Teacher(name, email);
        }
        if(type.equals("pesquisador"))
        {
            contributor = new Researcher(name, email);
        }
        if(contributor!=null)
        {
            system.contributors.put(email, contributor);
        } 
    }
    
    public void CreateProject(Sys system){
       Project project = new Project();
       System.out.print("Título: ");
       String title = input.nextLine();
       while(system.VerifyTitle(title)==true)
       {
           System.out.println("Esse título já existe, digite outro.");
           System.out.print("Título: ");
           title = input.nextLine();
       }
       project.setTitle(title);
       int startDate = Treatment("Data de inicio(ano): ");
       project.setStartDate(startDate);
       int finalDate = Treatment("Data de termino(ano): ");
       project.setFinalDate(finalDate);
       input.nextLine();
       System.out.print("Agência financiadora: ");
       String fundingAgency = input.nextLine();
       project.setFundingAgency(fundingAgency);
       int FinancedAmount = Treatment("Valor Financiado: ");
       project.setFinancedAmount(FinancedAmount);
       input.nextLine();
       System.out.print("Objetivo: ");
       String goal = input.nextLine();
       project.setGoal(goal);
       System.out.print("Descrição: ");
       String description = input.nextLine();
       project.setDescription(description);
       project.setVerification(1);
       project.setStatus("elaboracao");
       system.elaboration.add(project);
       
    }
    
    public void ParticipantAllocation(Sys system){
        System.out.print("Email do colaborador: ");
        String email = input.nextLine();
        Person participant;
        Project pj;
        while(!system.contributors.containsKey(email))
        {
            System.out.println("Nenhum colaborador com esse email foi encontrado. Digite novamente");
            System.out.print("Email do colaborador: ");
            email = input.nextLine();
        }
        participant = system.contributors.get(email);
        System.out.print("Título do projeto: ");
        String project = input.nextLine();
        while(!system.VerifyTitle(project))
        {
            System.out.println("Nenhum projeto com esse título foi encontrado. Digite novamente");
            System.out.print("Título do projeto: ");
            project = input.nextLine();
        }
        pj = system.SearchProject(project);
        if(pj!=null)
        {
            System.out.println("Projeto encontrado na lista de projetos em elaboração");
            if(participant instanceof GraduateStudent)
            {
                if(((GraduateStudent) participant).AlreadyParticipating(pj.getTitle()))
                {
                    System.out.println("O estudante de graduação "+((GraduateStudent) participant).getName()+" já participa do projeto");
                }
                else
                {
                   System.out.println("O estudante de graduação "+((GraduateStudent) participant).getName()+" será adicionado ao projeto");
                   pj.Participants.add(participant);
                   ((GraduateStudent) participant).elaboration.add(pj);
                }
            }
            if(participant instanceof MasteringStudent)
            {
                if(((MasteringStudent) participant).AlreadyParticipating(pj.getTitle()))
                {
                    System.out.println("O estudante de mestrado "+((MasteringStudent) participant).getName()+" já participa do projeto");
                }
                else
                {
                   System.out.println("O estudante de mestrado "+((MasteringStudent) participant).getName()+" será adicionado ao projeto");
                   pj.Participants.add(participant);
                   ((MasteringStudent) participant).elaboration.add(pj);
                }
            }
            if(participant instanceof PhdStudent)
            {
                if(((PhdStudent) participant).AlreadyParticipating(pj.getTitle()))
                {
                    System.out.println("O estudante de doutorado "+((PhdStudent) participant).getName()+" já participa do projeto");
                }
                else
                {
                   System.out.println("O estudante de doutorado "+((PhdStudent) participant).getName()+" será adicionado ao projeto");
                   pj.Participants.add(participant);
                   ((PhdStudent) participant).elaboration.add(pj);
                }
            }
            if(participant instanceof Teacher)
            {
                if(((Teacher) participant).AlreadyParticipating(pj.getTitle()))
                {
                    System.out.println("O Professor "+((Teacher) participant).getName()+" já participa do projeto");
                }
                else
                {
                   System.out.println("O Professor "+((Teacher) participant).getName()+" será adicionado ao projeto");
                   pj.Teachers.add(participant);
                   ((Teacher) participant).elaboration.add(pj);
                }
            }
            if(participant instanceof Researcher)
            {
                if(((Researcher) participant).AlreadyParticipating(pj.getTitle()))
                {
                    System.out.println("O Pesquisador "+((Researcher) participant).getName()+" já participa do projeto");
                }
                else
                {
                   System.out.println("O Pesquisador"+((Researcher) participant).getName()+" será adicionado ao projeto");
                   pj.Participants.add(participant);
                   ((Researcher) participant).elaboration.add(pj);
                }
            }
            
        }
        else
        {
            System.out.println("Projeto não foi encontrado na lista de projetos em elaboração.");
            System.out.println("A alocação só é permitida quando o projeto está em elaboração.");
        }
    }
    
    public void ElaborationToProgress(Sys system)
    {
        System.out.println("Título do projeto: ");
        String title = input.nextLine();
        Project pj = system.SearchProject(title);
        if(pj!=null)
        {
            System.out.println("Projeto não encontrado.");
            if(pj.Teachers.size()>0 && pj.getVerification()==1)
            {
               pj.setStatus("progesso");
               pj.setVerification(2);
               system.inProgress.add(pj);
               system.elaboration.remove(pj);
               pj.VerifyGraduateStudent(pj);
            }
        }
        else
        {
            System.out.println("Projeto não encontrado.");
        }
        
    }
    
    public void ProgressToFinished(Sys system)
    {
        System.out.println("Título do projeto: ");
        String title = input.nextLine();
        Project pj = system.SearchProjectInProgress(title);
        if(pj!=null)
        {
            System.out.println("Projeto não encontrado.");
            if(pj.getVerification()==2 && pj.getStatus().equals("progresso") && pj.publi.size()>0)
            {
               pj.setStatus("concluido");
               pj.setVerification(3);
               system.finished.add(pj);
               system.inProgress.remove(pj);
               pj.VerifyStudent(pj);
            }
        }
        else
        {
            System.out.println("Projeto não encontrado.");
        }
    }
    
    public void CreatePublication(Sys system){
        
        System.out.print("Título: ");
        String title = input.nextLine();
        while(system.VerifyPublication(title)!=null)
        {
            System.out.println("Já existe uma publicação com esse título.");
            System.out.print("Título: ");
            title = input.nextLine();
        }
        System.out.print("Nome da conferência: ");
        String name = input.nextLine();
        int year = Treatment("Ano de publicação: ");
        input.nextLine();
        Publications publication = new Publications(title, name, year);
        system.publications.add(publication);
    }
    
    public void AddAuthorsToPublication(Sys system){
        String author = "inicio";
        System.out.println("Título da publicação: ");
        String title = input.nextLine();
        Publications publi = system.VerifyPublication(title);
        if(publi!=null)
        {
            while(!author.equals("sair"))
            {
                System.out.println("Digite o email do colaborador que será um autor de "+publi.getTitle()+" ou sair.");
                author = input.nextLine();
                if(system.contributors.containsKey(author))
                {
                    Person col = system.contributors.get(author);
                    if(publi.VerifyParticipants(author)==false)
                    {
                        System.out.println("O colaborador "+col.getName()+" com o email "+col.getEmail()+" será um dos autores da publicação "+publi.getTitle());
                        col.publications.add(publi);
                        publi.authors.add(col);
                    }
                    else
                    {
                        System.out.println("O Colaborador não pode ser adicionado pois já faz parte da publicação.");
                    }
                }
            }
        }
        
        
    }
    
    public void AddProjectToPublication(Sys system){
        System.out.println("Título do projeto: ");
        String projectTitle = input.nextLine();
        System.out.println("Título da publicação: ");
        String publiTitle = input.nextLine();
        Project project;
        project = system.SearchProjectInProgress(projectTitle);
        if(project!=null)
        {
            System.out.println("Projeto encontrado.");
            Publications publi = system.VerifyPublication(publiTitle);
            if(publi!=null)
            {
                System.out.println("Publicação encontrada");
                if(project.getStatus().equals("progresso") && project.getVerification()==2)
                {
                   
                    if(publi.associatedProject==null)
                    {
                        if(project.VerifyPublicationAssociation(publiTitle)==false)
                        {
                            System.out.println("Projeto adicionado a publicação com sucesso!");
                            publi.associatedProject = project;
                            project.publi.add(publi);
                        }
                        else
                        {
                            System.out.println("Essa publicação já está associada a esse projeto.");
                        }                 
                    }
                    else
                    {
                        System.out.println("Já existe um projeto associado a essa publicação.");
                    }
                }
                else
                {
                    System.out.println("O projeto não está em fase de progresso");
                }
            }
            else
            {
                System.out.println("Publicação não encontrada.");
            }
        }
        else
        {
            System.out.println("Projeto não encontrado.");
        }
        
        
        
    }
    
    public void AddPublicationToProject(Sys system)
    {
        System.out.println("Título do projeto: ");
        String projectTitle = input.nextLine();
        System.out.println("Título da publicação: ");
        String publiTitle = input.nextLine();
        Project project;
        project = system.SearchProjectInProgress(projectTitle);
        if(project!=null)
        {
            System.out.println("Projeto encontrado.");
            Publications publi = system.VerifyPublication(publiTitle);
            if(project.getStatus().equals("progresso") && project.getVerification()==2)
            {
                if(publi!=null)
                {
                    System.out.println("Publicação encontrada.");
                    if(project.VerifyPublicationAssociation(publiTitle)==false)
                    {
                        project.publi.add(publi);
                        System.out.println("Publicação associada a projeto.");
                    }
                    else
                    {
                        System.out.println("Essa publicação já está associada a esse projeto.");
                    }
                }
            }
            else
            {
                System.out.println("Projeto não está em fase de progresso.");
            }
            
        }
        else
        {
            System.out.println("Projeto não encontrado.");
        }
    }
    
    public void CreateOrientation(Sys system)
    {
        System.out.print("Título: ");
        String title = input.nextLine();
        while(system.VerifyOrientation(title)!=null)
        {
            System.out.println("Já existe uma orientação com esse título.");
            System.out.print("Título: ");
            title = input.nextLine();
        }
        System.out.print("Nome da conferência: ");
        String name = input.nextLine();
        int year = Treatment("Ano: ");
        input.nextLine();
        Orientations ori = new Orientations(title, name, year);
        system.orientations.add(ori);
    }
    
    public void AddTeachersToOrientation(Sys system)
    {
        String email = "inicio";
        System.out.print("Título: ");
        String title = input.nextLine();
        Orientations ori = system.VerifyOrientation(title);
        if(ori!=null)
        {
            System.out.println("Orientação encontrada.");
            while(!email.equals("sair"))
            {
                System.out.println("Digite o email do professor que será um dos responsáveis pela orientação ou sair");
                email = input.nextLine();
                if(system.contributors.containsKey(email))
                {
                    System.out.println("Colaborador encontrado.");
                    Person person = system.contributors.get(email);
                    if(person instanceof Teacher)
                    {
                        System.out.println("O colaborador é um professor.");
                        if(ori.VerifyParticipationTeacher(email)==false)
                        {
                            ori.teachers.add(person);
                            ((Teacher) person).orientations.add(ori);
                            System.out.println("Agora o "+person.getName()+" é um dos responsáveis pela orientação.");
                        }
                        else
                        {
                            System.out.println("Esse professor já é um dos responsáveis pela orientação.");
                        }
                    }
                    else
                    {
                        System.out.println("O colaborador não é um professor.");
                    }
                }
                else
                {
                    System.out.println("Colaborador não encontrado.");
                }
            }
        }
        else
        {
            System.out.println("Orientação não encontrada.");
        }
    }
    
    public void AddStudentToOrientation(Sys system)
    {
        String email = "inicio";
        System.out.print("Título: ");
        String title = input.nextLine();
        Orientations ori = system.VerifyOrientation(title);
        if(ori!=null)
        {
            System.out.println("Orientação encontrada.");
            while(!email.equals("sair"))
            {
                System.out.println("Digite aqui o nome do colaborador que fará parte da orientação ou digite sair.");
                email = input.nextLine();
                if(system.contributors.containsKey(email))
                {
                    System.out.println("Colaborador encontrado.");
                    Person person = system.contributors.get(email);
                    if(ori.VerifyParticipationStudent(email)==false && ori.VerifyParticipationTeacher(email)==false)
                    {
                        ori.students.add(person);
                    }
                    else
                    {
                        System.out.println("O colaborador já faz parte da orientação");
                    }
                }
                else
                {
                    System.out.println("Colaborador não encontrado.");
                }
                
            }
        }
        else
        {
            System.out.println("Orientação não encontrada.");
        }
    }
    
    public void ConsultingCollaborator(Sys system)
    {
        System.out.print("Email do Colaborador: ");
        String email = input.nextLine();
        Person person = system.contributors.get(email);
        if(person!=null)
        {
            System.out.println("Colaborador encontrado.");
            
        }
        else
        {
            System.out.println("Colaborador não encontrado.");
        }
    }
    
    public void ConsultingProject(Sys system)
    {
        
    }
    
    public void RunReport(Sys system)
    {
        int total = system.contributors.size()+system.elaboration.size()+system.finished.size();
        System.out.println("Número de colaboradores: "+system.contributors.size());
        System.out.println("Número de projetos em elaboração: "+system.elaboration.size());
        System.out.println("Número de projetos em andamento: "+system.inProgress.size());
        System.out.println("Número de projetos concluídos: "+system.finished.size());
        System.out.println("Número total de projetos: "+total);
        System.out.println("Número de publicações: "+system.publications.size());
        System.out.println("Número de orientações: "+system.orientations.size());
    }
    public int Treatment(String message){
        boolean correctInput = false;
        int option=0;
        while(!correctInput){
            try{
                System.out.print(message);
                option = Integer.parseInt(input.next());
                correctInput= true;
            } catch(NumberFormatException e){
                System.out.println("O valor desejado é um número inteiro.");
            }
        }
        return option;
    }
}
