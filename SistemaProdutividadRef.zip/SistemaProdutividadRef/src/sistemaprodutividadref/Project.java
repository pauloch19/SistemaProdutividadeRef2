/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;

/**
 *
 * @author paulc
 */
public class Project {
    private int verification = 0;
    private int startDate;
    private int finalDate;
    private int financedAmount;
    private String title;
    private String fundingAgency;
    private String goal;
    private  String description;
    private String status;
    java.util.ArrayList<Person> Participants = new java.util.ArrayList<>();
    java.util.ArrayList<Person> Teachers = new java.util.ArrayList<>();
    java.util.ArrayList<Publications> publi = new java.util.ArrayList<>();
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    public int getVerification() {
        return verification;
    }

    public void setVerification(int verification) {
        this.verification = verification;
    }

    public int getStartDate() {
        return startDate;
    }

    public void setStartDate(int startDate) {
        this.startDate = startDate;
    }

    public int getFinalDate() {
        return finalDate;
    }

    public void setFinalDate(int finalDate) {
        this.finalDate = finalDate;
    }

    public int getFinancedAmount() {
        return financedAmount;
    }

    public void setFinancedAmount(int financedAmount) {
        this.financedAmount = financedAmount;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getFundingAgency() {
        return fundingAgency;
    }

    public void setFundingAgency(String fundingAgency) {
        this.fundingAgency = fundingAgency;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
    public void VerifyGraduateStudent(Project pj){
        
        int i;
        Person student;
        for(i=0;i<Participants.size();i++)
        {
            student = Participants.get(i);
            if(student instanceof GraduateStudent)
            {
                if(((GraduateStudent) student).inProgress.size()<2)
                {
                    ((GraduateStudent) student).elaboration.remove(pj);
                    ((GraduateStudent) student).inProgress.add(pj);
                }
                else
                {
                    System.out.println("O estudante já participa de dois projetos em andamento.");
                    System.out.println("Ele será removido do projeto atual.");
                    ((GraduateStudent) student).elaboration.remove(pj);
                    Participants.remove(i);
                }
            }
            else
            {
               student.elaboration.remove(pj);
               student.inProgress.add(pj);
            }
        }
        
    }
    
    public void VerifyStudent(Project pj){
        
        int i;
        Person student;
        for(i=0;i<Participants.size();i++)
        {
            student = Participants.get(i); 
            student.finished.add(pj);
            student.inProgress.remove(pj);
        }
        
    }
    
    public boolean VerifyPublicationAssociation(String title)
    {
        int i;
        Publications pb;
        boolean found = false;
        for(i=0;i<publi.size();i++)
        {
            pb = publi.get(i);
            if(pb.getTitle().equals(title))
            {
                found = true;
                break;
            }
        }
        return found;
    }
    
}
