/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;

/**
 *
 * @author paulc
 */
public class AcademicsProductions {
    private String title;
    private String conferenceName;
    private int year;
    
    public AcademicsProductions(String title, String conferenceName, int year){
        this.title= title;
        this.conferenceName= conferenceName;
        this.year = year;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getConferenceName() {
        return conferenceName;
    }

    public void setConferenceName(String conferenceName) {
        this.conferenceName = conferenceName;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
    
    
    
}
