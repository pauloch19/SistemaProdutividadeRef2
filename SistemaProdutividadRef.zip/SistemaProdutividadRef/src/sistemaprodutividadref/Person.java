/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;

/**
 *
 * @author paulc
 */
public class Person{
    private String name;
    private String email;
    java.util.ArrayList<Project> elaboration= new java.util.ArrayList<>();
    java.util.ArrayList<Project> inProgress= new java.util.ArrayList<>();
    java.util.ArrayList<Project> finished = new java.util.ArrayList<>();
    java.util.ArrayList<Publications> publications = new java.util.ArrayList<>();
    
    public Person(String name, String email){
        this.name = name;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String toString(){
        
        return "Nome: "+name+"\nEmail: "+email;
    }
    
}
