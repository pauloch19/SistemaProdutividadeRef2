/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemaprodutividadref;

/**
 *
 * @author paulc
 */
public class PhdStudent extends Person implements CollaboratorsTools{
    
    public PhdStudent(String name, String email){
        super(name, email);
    }
    
    
    public boolean AlreadyParticipating(String title)
    {
        int i;
        boolean found = false;
        Project pj;
        for(i=0;i<super.elaboration.size();i++)
        {
            pj = super.elaboration.get(i);
            if(pj.getTitle().equals(title))
            {
                found = true;
                break;
            }
        }
        return found;
    }
    
    @Override
    public String toString(){
        return super.toString();
    }
}
